package com.example.demo1;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        double totalCost = 0.0;

        // пальто (со скидкой 77%)
        double coatPrice = 70.0;
        double coatDiscount = 0.77;
        double coatTotal = coatPrice * (1 - coatDiscount);
        totalCost += coatTotal;

        // шляпа (со скидкой 37%)
        double hatPrice = 25.0;
        double hatDiscount = 0.37;
        double hatTotal = hatPrice * (1 - hatDiscount);
        totalCost += hatTotal;

        // деловой костюм (со скидкой 44%)
        double suitPrice = 53.0;
        double suitDiscount = 0.44;
        double suitTotal = suitPrice * (1 - suitDiscount);
        totalCost += suitTotal;

        // сорочка (без скидки)
        double shirtPrice = 19.0;
        totalCost += shirtPrice;

        // туфли (со скидкой 32%)
        double shoesPrice = 41.0;
        double shoesDiscount = 0.32;
        double shoesTotal = shoesPrice * (1 - shoesDiscount);
        totalCost += shoesTotal;

        // проверяем, хватает ли денег на покупку гардероба
        double accountBalance = 312.0;
        if (accountBalance >= totalCost) {
            System.out.println("Денег хватает! Общая сумма покупок: " + totalCost);
        } else {
            System.out.println("Денег не хватает! Общая сумма покупок: " + totalCost);
        }
    }
}
/**
 * Для Алексея.
 * Тут простенький код изученный из простора гугла,
 * Вообщем картина проста, меняете сумму в коде, меняется ответ, в зависимости хватит деняг или нет, ну это очень понятный код.
 */